class Expense:
    def __init__(self, amount, date, category):
        self.amount = amount
        self.date = date
        self.category = category
