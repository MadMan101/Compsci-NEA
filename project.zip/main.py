from ui.app import BudgetTrackerApp
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    app = BudgetTrackerApp(root)
    root.mainloop()
